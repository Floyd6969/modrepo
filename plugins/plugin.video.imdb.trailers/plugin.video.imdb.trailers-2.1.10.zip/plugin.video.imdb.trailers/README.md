# plugin.video.imdb.trailers
## Kodi Addon for playing trailers from IMDb website
![Build Status](https://img.shields.io/travis/Gujal00/plugin.video.imdb.trailers/master.svg)
![License](https://img.shields.io/badge/license-GPL--3.0--only-success.svg)
![Kodi Version](https://img.shields.io/badge/kodi-leia%2B-success.svg)
![Contributors](https://img.shields.io/github/contributors/Gujal00/plugin.video.imdb.trailers.svg)

Head to the [Forum for support](https://forum.kodi.tv/showthread.php?tid=352127)
